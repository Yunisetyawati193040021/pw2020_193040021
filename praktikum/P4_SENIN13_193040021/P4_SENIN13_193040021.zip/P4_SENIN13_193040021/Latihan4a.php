<?php
$huruf = ["ada","abel","men","pung","nilai"];
echo "Array $huruf[0]lah suatu vari$huruf[1] yang dapat $huruf[2]am$huruf[3] banyak $huruf[4]";
?>
<br></br>
<tr>
    <h3><a href="index.php">Back</a></h3>
</tr>