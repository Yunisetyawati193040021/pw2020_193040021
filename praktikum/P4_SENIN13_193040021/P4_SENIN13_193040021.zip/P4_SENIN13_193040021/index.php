<!DOCTYPE html>
<html>
<head>
	<title>Index.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<div class="header">
		<marquee behavior="alternate"><i>Welcome!</i> MY INDEX.COM</marquee>
        <div class="hero"></div>
            <ul>
                <h5>LATIHAN</h5>
                <a href="Latihan4a.php">Latihan4a</a></li>
				<a href="Latihan4b.php">Latihan4b</a></li>
                <a href="Latihan4c.php">Latihan4c</a></li>
                <a href="Latihan4d.php">Latihan4d</a></li>
                <h5>TUGAS</h5>
                <a href="Tugas2.php">Tugas2</a>
            </ul>
		</div>

		<div class="content"></div>
    </div>
    <div id="footer">
		<p align="center">Copyright &copy; 2020 Yuni Setyawati 193040021</p>
    </div>
</body>
</html>