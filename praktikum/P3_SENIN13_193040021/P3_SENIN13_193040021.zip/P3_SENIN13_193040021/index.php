<!DOCTYPE html>
<html>
<head>
	<title>Index.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<div class="header">
			<marquee><i>Welcome!</i> MY INDEX.COM</marquee>
            <div class="hero"></div>
            <ul>
                <h5>LATIHAN</h5>
                <a href="Latihan3a.php">Latihan3a</a></li>
				<a href="Latihan3b.php">Latihan3b</a></li>
                <a href="Latihan3c.php">Latihan3c</a></li>
                <a href="Latihan3d.php">Latihan3d</a></li>
            </ul>
		</div>

		<div class="content"></div>
    </div>
    <div id="footer">
			<p align="center">Copyright &copy; 2020 Yuni Setyawati 193040021</p>
        </div>
</body>
</html>