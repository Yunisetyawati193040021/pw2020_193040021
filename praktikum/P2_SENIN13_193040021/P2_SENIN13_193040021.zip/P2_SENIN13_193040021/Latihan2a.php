<?php
    for ($i = 1; $i <=3; $i++) {
        for ($b = 1; $b <=3; $b++){
            echo "Ini pengulangan ke ($i, $b)<br>";
        }
    }
?>
<br></br>
<tr>
    <h3><a href="index.php">Back</a></h3>
</tr>