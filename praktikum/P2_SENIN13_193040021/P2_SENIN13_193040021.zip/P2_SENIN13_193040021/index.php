<!DOCTYPE html>
<html>
<head>
	<title>Index.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<div class="header">
			<marquee><i>Welcome!</i> MY INDEX.COM</marquee>
            <div class="hero"></div>
            <ul>
                <h5>LATIHAN</h5>
                <a href="Latihan2a.php">Latihan2a</a></li>
				<a href="Latihan2b.php">Latihan2b</a></li>
                <a href="Latihan2c.php">Latihan2c</a></li>
                <h5>TUGAS</h5>
                <a href="Tugas1.php">Tugas1</a>
            </ul>
		</div>

		<div class="content"></div>
    </div>
    <div id="footer">
			<p align="center">Copyright &copy; 2020 Yuni Setyawati 193040021</p>
        </div>
</body>
</html>